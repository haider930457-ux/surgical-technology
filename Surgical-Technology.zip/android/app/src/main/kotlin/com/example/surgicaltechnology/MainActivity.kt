package com.example.surgicaltechnology

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
