import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Surgical Technology',
      home: const HomeApp(),
    );
  }
}

class HomeApp extends StatefulWidget {
  const HomeApp({super.key});
  @override
  State<HomeApp> createState() => _HomeAppState();
}

class _HomeAppState extends State<HomeApp> {
  int bottomIndex = 0;
  bool isGrid = true;
  String currentPage = "home";
  String booksTab = "books";
  Map<String, dynamic>? selectedItem;

  // MODULES - 7 modules, Books & Slides combined
  List<Map<String, dynamic>> modules = [
    {
      "id": "library",
      "title": "Instrument Library",
      "count": "120 items",
      "icon": Icons.content_cut,
      "color": Color(0xFF0F5CA8),
      "light": Color(0xFFEFF6FF),
      "active": true
    },
    {
      "id": "procedures",
      "title": "Surgical Procedures",
      "count": "50+ guides",
      "icon": Icons.assignment,
      "color": Color(0xFFEA580C),
      "light": Color(0xFFFFF7ED),
      "active": true
    },
    {
      "id": "books",
      "title": "Medical Books & Slides",
      "count": "50 books + 200 slides",
      "icon": Icons.menu_book,
      "color": Color(0xFF0E7490),
      "light": Color(0xFFECFEFF),
      "active": true,
      "isNew": true
    },
    {
      "id": "cssd",
      "title": "CSSD Sterilization",
      "count": "Protocols",
      "icon": Icons.local_fire_department,
      "color": Color(0xFF7C3AED),
      "light": Color(0xFFF5F3FF),
      "active": false
    },
    {
      "id": "ot",
      "title": "OT Protocols",
      "count": "Checklists",
      "icon": Icons.medical_services,
      "color": Color(0xFF0F766E),
      "light": Color(0xFFF0FDFA),
      "active": false
    },
    {
      "id": "mcq",
      "title": "MCQ Bank",
      "count": "800+ Qs",
      "icon": Icons.quiz,
      "color": Color(0xFFBE185D),
      "light": Color(0xFFFFF1F2),
      "active": false
    },
    {
      "id": "anatomy",
      "title": "Anatomy Atlas",
      "count": "Visual",
      "icon": Icons.favorite,
      "color": Color(0xFF1D4ED8),
      "light": Color(0xFFEFF6FF),
      "active": false
    },
  ];

  List<Map<String, dynamic>> instruments = [
    {
      "name": "Artery Forceps",
      "cat": "Grasping",
      "use": "Clamp blood vessels",
      "color": Color(0xFFDBEAFE)
    },
    {
      "name": "Scalpel Handle",
      "cat": "Cutting",
      "use": "Make incisions",
      "color": Color(0xFFFEF3C7)
    },
    {
      "name": "Needle Holder",
      "cat": "Suturing",
      "use": "Hold needle",
      "color": Color(0xFFD1FAE5)
    },
    {
      "name": "Retractor",
      "cat": "Retracting",
      "use": "Retract tissue",
      "color": Color(0xFFFCE7F3)
    },
    {
      "name": "Scissors",
      "cat": "Cutting",
      "use": "Cut tissues",
      "color": Color(0xFFFFEDD5)
    },
  ];

  List<Map<String, dynamic>> books = [
    {
      "title": "OT Technology Basics",
      "author": "Dr. Sharma",
      "pages": "250 pages",
      "color": Color(0xFFECFEFF)
    },
    {
      "title": "Surgical Instruments Atlas",
      "author": "Pepar",
      "pages": "180 pages",
      "color": Color(0xFFFFF7ED)
    },
    {
      "title": "CSSD Manual",
      "author": "WHO",
      "pages": "120 pages",
      "color": Color(0xFFF0FDFA)
    },
  ];

  List<Map<String, dynamic>> slides = [
    {
      "title": "Scrubbing & Gowning",
      "count": "15 slides",
      "desc": "WHO technique",
      "color": Color(0xFFEEF2FF)
    },
    {
      "title": "OT Fumigation",
      "count": "12 slides",
      "desc": "Formalin protocol",
      "color": Color(0xFFEFF6FF)
    },
    {
      "title": "Suture Materials",
      "count": "20 slides",
      "desc": "Vicryl, Silk",
      "color": Color(0xFFFFF1F2)
    },
    {
      "title": "Autoclave Operation",
      "count": "18 slides",
      "desc": "How to operate",
      "color": Color(0xFFF0FDFA)
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8FAFC),
      body: _getBody(),
      bottomNavigationBar: selectedItem != null ? null : _bottomNav(),
      floatingActionButton: _getFab(),
    );
  }

  Widget _getBody() {
    if (selectedItem != null) return _detailPage();
    if (currentPage == "library") return _libraryPage();
    if (currentPage == "books") return _booksAndSlidesPage();
    if (currentPage == "procedures")
      return _simplePage("Surgical Procedures", "50+ guides coming soon");
    if (bottomIndex == 1) return _libraryPage();
    if (bottomIndex == 2)
      return _simplePage("Learn", "Learn module coming soon");
    if (bottomIndex == 3) return _simplePage("Quiz", "Quiz module coming soon");
    if (bottomIndex == 4) return _profilePage();
    return _homePage();
  }

  Widget? _getFab() {
    if (selectedItem != null) return null;
    if (currentPage == "home" && bottomIndex != 0) return null;
    if (currentPage == "home") return null;
    return FloatingActionButton.extended(
      backgroundColor: Color(0xFF0F172A),
      icon: Icon(Icons.add, color: Colors.white),
      label: Text(
          "Add ${currentPage == "library" ? "Instrument" : currentPage == "books" ? (booksTab == "books" ? "Book" : "Slide") : "Item"}",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      onPressed: () => _showAddDialog(),
    );
  }

  Widget _homePage() {
    return SafeArea(
      child: Column(
        children: [
          // Header - NO grid toggle here (only in modules)
          Container(
            color: Colors.white,
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Surgical Technology",
                            style: TextStyle(
                                fontWeight: FontWeight.w900, fontSize: 22)),
                        SizedBox(height: 4),
                        Text("OT Technologist Guidelines • v2.4",
                            style: TextStyle(fontSize: 12, color: Colors.grey)),
                      ],
                    ),
                    Row(
                      children: [
                        CircleAvatar(
                            backgroundColor: Color(0xFFF1F5F9),
                            child: Icon(Icons.search, size: 20)),
                        SizedBox(width: 8),
                        Stack(children: [
                          CircleAvatar(
                              backgroundColor: Color(0xFFF1F5F9),
                              child: Icon(Icons.notifications_none, size: 20)),
                          Positioned(
                              top: 6,
                              right: 8,
                              child: Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                      color: Colors.red,
                                      shape: BoxShape.circle))),
                        ]),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 16),
                // Blue stats card
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [Color(0xFF0F5CA8), Color(0xFF3B82F6)]),
                      borderRadius: BorderRadius.circular(20)),
                  child: Row(
                    children: [
                      Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                            Text("120+",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18)),
                            Text("INSTRUMENTS",
                                style: TextStyle(
                                    color: Colors.white70, fontSize: 10))
                          ])),
                      Container(width: 1, height: 30, color: Colors.white24),
                      Expanded(
                          child: Padding(
                              padding: EdgeInsets.only(left: 16),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("50+",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18)),
                                    Text("PROCEDURES",
                                        style: TextStyle(
                                            color: Colors.white70,
                                            fontSize: 10))
                                  ]))),
                      Container(width: 1, height: 30, color: Colors.white24),
                      Expanded(
                          child: Padding(
                              padding: EdgeInsets.only(left: 16),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(children: [
                                      Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                              color: Colors.greenAccent,
                                              shape: BoxShape.circle)),
                                      SizedBox(width: 4),
                                      Text("Offline",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12))
                                    ]),
                                    Text("READY",
                                        style: TextStyle(
                                            color: Colors.white70,
                                            fontSize: 10))
                                  ]))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Learning Modules header WITH grid toggle ONLY HERE
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Text("Learning Modules",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    SizedBox(width: 8),
                    Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                            color: Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(12)),
                        child: Text("${modules.length} Modules",
                            style: TextStyle(
                                color: Color(0xFF0F5CA8),
                                fontSize: 12,
                                fontWeight: FontWeight.bold))),
                  ],
                ),
                Container(
                  decoration: BoxDecoration(
                      color: Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(20)),
                  child: Row(
                    children: [
                      InkWell(
                          onTap: () => setState(() => isGrid = true),
                          child: Container(
                              padding: EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: isGrid
                                      ? Color(0xFF0F5CA8)
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Icon(Icons.grid_view,
                                  size: 18,
                                  color: isGrid ? Colors.white : Colors.grey))),
                      InkWell(
                          onTap: () => setState(() => isGrid = false),
                          child: Container(
                              padding: EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: !isGrid
                                      ? Color(0xFF0F5CA8)
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Icon(Icons.view_list,
                                  size: 18,
                                  color:
                                      !isGrid ? Colors.white : Colors.grey))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Modules grid/list
          Expanded(
            child: isGrid
                ? GridView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.95),
                    itemCount: modules.length,
                    itemBuilder: (c, i) {
                      final m = modules[i];
                      return InkWell(
                        onTap: () {
                          setState(() {
                            if (m["id"] == "library")
                              currentPage = "library";
                            else if (m["id"] == "books")
                              currentPage = "books";
                            else if (m["id"] == "procedures")
                              currentPage = "procedures";
                          });
                        },
                        onLongPress: () => _showEditModuleDialog(i),
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: Color(0xFFF1F5F9))),
                          padding: EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: m["light"] as Color,
                                      borderRadius: BorderRadius.circular(12)),
                                  child: Icon(m["icon"] as IconData,
                                      color: m["color"] as Color, size: 22)),
                              Spacer(),
                              Text(m["title"] as String,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13),
                                  maxLines: 2),
                              SizedBox(height: 4),
                              Text(m["count"] as String,
                                  style: TextStyle(
                                      fontSize: 11, color: Colors.grey)),
                              SizedBox(height: 8),
                              Row(children: [
                                Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(
                                        color: (m["active"] as bool)
                                            ? Color(0xFF0F5CA8)
                                            : Colors.grey,
                                        shape: BoxShape.circle)),
                                SizedBox(width: 4),
                                Text(
                                    (m["active"] as bool) ? "Active" : "Locked",
                                    style: TextStyle(
                                        fontSize: 11,
                                        color: (m["active"] as bool)
                                            ? Color(0xFF0F5CA8)
                                            : Colors.grey,
                                        fontWeight: FontWeight.bold)),
                                if (m.containsKey("isNew")) ...[
                                  SizedBox(width: 4),
                                  Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                          color: Colors.green,
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      child: Text("NEW",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 7,
                                              fontWeight: FontWeight.bold)))
                                ],
                                Spacer(),
                                Icon(Icons.edit, size: 12, color: Colors.grey),
                              ]),
                            ],
                          ),
                        ),
                      );
                    },
                  )
                : ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    itemCount: modules.length,
                    itemBuilder: (c, i) {
                      final m = modules[i];
                      return Container(
                        margin: EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border(
                                left: BorderSide(
                                    color: m["color"] as Color, width: 4))),
                        child: ListTile(
                          leading: Container(
                              padding: EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: m["light"] as Color,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Icon(m["icon"] as IconData,
                                  color: m["color"] as Color)),
                          title: Text(m["title"] as String,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 13)),
                          subtitle: Text(m["count"] as String,
                              style: TextStyle(fontSize: 11)),
                          trailing:
                              Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.edit, size: 14, color: Colors.grey),
                            SizedBox(width: 8),
                            Icon(
                                (m["active"] as bool)
                                    ? Icons.check_circle
                                    : Icons.lock,
                                size: 18,
                                color: (m["active"] as bool)
                                    ? Colors.green
                                    : Colors.grey)
                          ]),
                          onTap: () {
                            setState(() {
                              if (m["id"] == "library")
                                currentPage = "library";
                              else if (m["id"] == "books")
                                currentPage = "books";
                            });
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _libraryPage() {
    return SafeArea(
      child: Column(
        children: [
          Container(
              color: Colors.white,
              padding: EdgeInsets.all(16),
              child: Row(children: [
                IconButton(
                    icon: Icon(Icons.arrow_back),
                    onPressed: () => setState(() {
                          currentPage = "home";
                          bottomIndex = 0;
                        })),
                Text("Instrument Library",
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                Spacer(),
                IconButton(
                    icon: Icon(Icons.edit), onPressed: () => _showAdminInfo()),
                Text("Admin",
                    style: TextStyle(
                        fontSize: 10,
                        color: Color(0xFF0F5CA8),
                        fontWeight: FontWeight.bold))
              ])),
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: instruments.length,
              itemBuilder: (c, i) {
                final ins = instruments[i];
                return Dismissible(
                  key: Key(ins["name"]),
                  direction: DismissDirection.endToStart,
                  background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: EdgeInsets.only(right: 20),
                      child: Icon(Icons.delete, color: Colors.white)),
                  onDismissed: (_) => setState(() => instruments.removeAt(i)),
                  child: Container(
                    margin: EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14)),
                    child: ListTile(
                      leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                              color: ins["color"] as Color,
                              borderRadius: BorderRadius.circular(10)),
                          child: Center(
                              child:
                                  Text("🔧", style: TextStyle(fontSize: 20)))),
                      title: Text(ins["name"] as String,
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text("${ins["cat"]} • ${ins["use"]}",
                          style: TextStyle(fontSize: 11)),
                      trailing: Icon(Icons.edit, size: 16, color: Colors.grey),
                      onTap: () => setState(() => selectedItem = ins),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _booksAndSlidesPage() {
    return SafeArea(
      child: Column(
        children: [
          Container(
            color: Colors.white,
            padding: EdgeInsets.all(12),
            child: Column(
              children: [
                Row(children: [
                  IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: () => setState(() => currentPage = "home")),
                  Expanded(
                      child: Text("Medical Books & Slides",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16))),
                  Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                          color: Color(0xFF0E7490),
                          borderRadius: BorderRadius.circular(12)),
                      child: Text("Admin Editable",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold)))
                ]),
                SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                      color: Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      Expanded(
                          child: InkWell(
                              onTap: () => setState(() => booksTab = "books"),
                              child: Container(
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  decoration: BoxDecoration(
                                      color: booksTab == "books"
                                          ? Color(0xFF0E7490)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(12)),
                                  child: Center(
                                      child: Text("📚 Books (${books.length})",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                              color: booksTab == "books"
                                                  ? Colors.white
                                                  : Colors.grey)))))),
                      Expanded(
                          child: InkWell(
                              onTap: () => setState(() => booksTab = "slides"),
                              child: Container(
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  decoration: BoxDecoration(
                                      color: booksTab == "slides"
                                          ? Color(0xFF4338CA)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(12)),
                                  child: Center(
                                      child: Text(
                                          "🎞️ Slides (${slides.length})",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                              color: booksTab == "slides"
                                                  ? Colors.white
                                                  : Colors.grey)))))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: booksTab == "books"
                ? ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: books.length,
                    itemBuilder: (c, i) {
                      final b = books[i];
                      return Dismissible(
                        key: Key(b["title"]),
                        direction: DismissDirection.endToStart,
                        background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: EdgeInsets.only(right: 20),
                            child: Icon(Icons.delete, color: Colors.white)),
                        onDismissed: (_) => setState(() => books.removeAt(i)),
                        child: Container(
                          margin: EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14)),
                          child: ListTile(
                            leading: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                    color: b["color"] as Color,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Center(
                                    child: Text("📘",
                                        style: TextStyle(fontSize: 20)))),
                            title: Text(b["title"] as String,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 13)),
                            subtitle: Text("${b["author"]} • ${b["pages"]}",
                                style: TextStyle(fontSize: 11)),
                            trailing:
                                Row(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.edit, size: 14, color: Colors.grey),
                              SizedBox(width: 8),
                              Icon(Icons.picture_as_pdf,
                                  color: Color(0xFF0E7490), size: 20)
                            ]),
                            onTap: () => setState(() => selectedItem = b),
                          ),
                        ),
                      );
                    },
                  )
                : GridView.builder(
                    padding: EdgeInsets.all(16),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.9),
                    itemCount: slides.length,
                    itemBuilder: (c, i) {
                      final s = slides[i];
                      return Dismissible(
                        key: Key(s["title"]),
                        direction: DismissDirection.endToStart,
                        background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: EdgeInsets.only(right: 20),
                            child: Icon(Icons.delete, color: Colors.white)),
                        onDismissed: (_) => setState(() => slides.removeAt(i)),
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16)),
                          child: Column(
                            children: [
                              Container(
                                  height: 70,
                                  decoration: BoxDecoration(
                                      color: s["color"] as Color,
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(16))),
                                  child: Center(
                                      child: Text("🎞️",
                                          style: TextStyle(fontSize: 30)))),
                              Padding(
                                padding: EdgeInsets.all(10),
                                child: Column(children: [
                                  Text(s["title"] as String,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12),
                                      textAlign: TextAlign.center,
                                      maxLines: 2),
                                  SizedBox(height: 4),
                                  Text(s["count"] as String,
                                      style: TextStyle(
                                          fontSize: 10, color: Colors.grey)),
                                  SizedBox(height: 4),
                                  Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.edit,
                                            size: 12, color: Colors.grey),
                                        SizedBox(width: 4),
                                        Text("Editable",
                                            style: TextStyle(
                                                fontSize: 9,
                                                color: Colors.grey))
                                      ]),
                                ]),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _detailPage() {
    final item = selectedItem!;
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => setState(() => selectedItem = null)),
          title: Text(item["name"] ?? item["title"] ?? "Detail",
              style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
                icon: Icon(Icons.edit), onPressed: () => _showEditItemDialog())
          ]),
      body: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text("📘", style: TextStyle(fontSize: 60)),
        SizedBox(height: 16),
        Text(item["name"] ?? item["title"] ?? "",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        SizedBox(height: 8),
        Text("Fully editable from admin - You can edit/delete",
            style: TextStyle(color: Colors.grey)),
        SizedBox(height: 20),
        ElevatedButton.icon(
            icon: Icon(Icons.edit),
            label: Text("Edit this item"),
            onPressed: () => _showEditItemDialog())
      ])),
    );
  }

  Widget _simplePage(String title, String desc) {
    return SafeArea(
        child: Column(children: [
      Container(
          color: Colors.white,
          padding: EdgeInsets.all(16),
          child: Row(children: [
            IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () => setState(() {
                      currentPage = "home";
                      bottomIndex = 0;
                    })),
            Text(title,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))
          ])),
      Expanded(
          child: Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
            Icon(Icons.construction, size: 50, color: Colors.grey),
            SizedBox(height: 12),
            Text(desc, style: TextStyle(color: Colors.grey)),
            SizedBox(height: 12),
            ElevatedButton(
                onPressed: () => _showAddDialog(),
                child: Text("Add New - Admin Editable"))
          ])))
    ]));
  }

  Widget _profilePage() {
    return SafeArea(
        child: Center(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      CircleAvatar(
          radius: 40,
          backgroundColor: Color(0xFFEFF6FF),
          child: Text("OT",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0F5CA8),
                  fontSize: 24))),
      SizedBox(height: 12),
      Text("OT Technologist",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      Text("Admin Access • All folders editable",
          style: TextStyle(
              color: Colors.green, fontWeight: FontWeight.bold, fontSize: 12)),
      SizedBox(height: 20),
      ElevatedButton.icon(
          icon: Icon(Icons.settings),
          label: Text("Admin Settings - Edit All"),
          onPressed: () => _showAdminInfo())
    ])));
  }

  Widget _bottomNav() {
    return Container(
      margin: EdgeInsets.all(12),
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
          color: Color(0xFF0F172A), borderRadius: BorderRadius.circular(24)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(0, Icons.home_rounded, "Home"),
          _navItem(1, Icons.library_books_rounded, "Library"),
          _navItem(2, Icons.school_rounded, "Learn"),
          _navItem(3, Icons.emoji_events_rounded, "Quiz"),
          _navItem(4, Icons.person_rounded, "Profile"),
        ],
      ),
    );
  }

  Widget _navItem(int idx, IconData icon, String label) {
    final active = bottomIndex == idx && currentPage == "home";
    return InkWell(
      onTap: () => setState(() {
        bottomIndex = idx;
        currentPage = "home";
      }),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
                color: active ? Colors.white : Colors.transparent,
                borderRadius: BorderRadius.circular(20)),
            child: Icon(icon,
                size: 20, color: active ? Color(0xFF0F172A) : Colors.white54)),
        SizedBox(height: 4),
        Text(label,
            style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: active ? Colors.white : Colors.white54)),
      ]),
    );
  }

  void _showAddDialog() {
    final titleCtrl = TextEditingController();
    final subCtrl = TextEditingController();
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
                title: Text(
                    "Add New ${currentPage == "library" ? "Instrument" : booksTab == "books" ? "Book" : "Slide"} - Admin"),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: titleCtrl,
                      decoration: InputDecoration(
                          labelText: "Title", border: OutlineInputBorder())),
                  SizedBox(height: 10),
                  TextField(
                      controller: subCtrl,
                      decoration: InputDecoration(
                          labelText: "Details (Author/Use)",
                          border: OutlineInputBorder())),
                  SizedBox(height: 8),
                  Text(
                      "This will be editable/deletable anytime from mobile admin",
                      style: TextStyle(fontSize: 10, color: Colors.grey))
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("Cancel")),
                  ElevatedButton(
                      onPressed: () {
                        setState(() {
                          if (currentPage == "library" &&
                              titleCtrl.text.isNotEmpty)
                            instruments.add({
                              "name": titleCtrl.text,
                              "cat": "Custom",
                              "use": subCtrl.text,
                              "color": Color(0xFFDBEAFE)
                            });
                          else if (currentPage == "books" &&
                              booksTab == "books" &&
                              titleCtrl.text.isNotEmpty)
                            books.add({
                              "title": titleCtrl.text,
                              "author": subCtrl.text,
                              "pages": "New",
                              "color": Color(0xFFECFEFF)
                            });
                          else if (currentPage == "books" &&
                              booksTab == "slides" &&
                              titleCtrl.text.isNotEmpty)
                            slides.add({
                              "title": titleCtrl.text,
                              "count": "New",
                              "desc": subCtrl.text,
                              "color": Color(0xFFEEF2FF)
                            });
                        });
                        Navigator.pop(context);
                      },
                      child: Text("Add - Editable"))
                ]));
  }

  void _showEditItemDialog() {
    final item = selectedItem!;
    final ctrl =
        TextEditingController(text: item["name"] ?? item["title"] ?? "");
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
                title: Text("Edit - Admin"),
                content: TextField(
                    controller: ctrl,
                    decoration: InputDecoration(
                        labelText: "Edit Title", border: OutlineInputBorder())),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("Cancel")),
                  ElevatedButton(
                      onPressed: () {
                        setState(() {
                          if (item.containsKey("name"))
                            item["name"] = ctrl.text;
                          else
                            item["title"] = ctrl.text;
                        });
                        Navigator.pop(context);
                        setState(() => selectedItem = null);
                      },
                      child: Text("Save"))
                ]));
  }

  void _showEditModuleDialog(int idx) {
    final m = modules[idx];
    final ctrl = TextEditingController(text: m["title"] as String);
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
                title: Text("Edit Module - Admin"),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: ctrl,
                      decoration: InputDecoration(
                          labelText: "Module Name",
                          border: OutlineInputBorder())),
                  SizedBox(height: 10),
                  Text("Every folder is editable from admin on mobile",
                      style: TextStyle(fontSize: 11, color: Colors.grey))
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("Cancel")),
                  ElevatedButton(
                      onPressed: () {
                        setState(() => modules[idx]["title"] = ctrl.text);
                        Navigator.pop(context);
                      },
                      child: Text("Save"))
                ]));
  }

  void _showAdminInfo() {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
                title: Text("Admin Panel - All Editable"),
                content: Text(
                    "• Long press any module to edit name\n• Swipe left on any item to delete\n• Use + button to add new books/slides/instruments\n• Every folder is editable from your mobile\n• Books & Slides are combined in one module"),
                actions: [
                  ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("OK - Got it"))
                ]));
  }
}
